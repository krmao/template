### 放在 body 标签之后 注册

```nextjs
    <script type="text/javascript" src="/static/plugins/hybrid-console/hybird-console.js" />
    <link rel="stylesheet" href="/static/plugins/hybrid-console/hybird-console.css" />

    // 记得修改 js 中的路径前缀
    // let hostAddress = "/static/plugins/hybrid-console/";
```
